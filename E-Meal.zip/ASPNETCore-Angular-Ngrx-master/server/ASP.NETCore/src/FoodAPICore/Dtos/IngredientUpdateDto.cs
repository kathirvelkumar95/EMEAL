﻿namespace FoodAPICore.Dtos
{
    public class IngredientUpdateDto
    {
        public int Quantity { get; set; }

        public int Weight { get; set; }

        public string Description { get; set; }
    }
}
