export const environment = {
  production: true,
  mobile: false,
  desktop: false,
  server: 'https://conference-xplatform-server.azurewebsites.net/',
  apiUrl: 'api/',
};
