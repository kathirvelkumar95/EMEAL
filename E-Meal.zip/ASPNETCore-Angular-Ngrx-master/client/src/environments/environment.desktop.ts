export const environment = {
  production: true,
  mobile: false,
  desktop: true,
  server: 'https://conference-xplatform-server.azurewebsites.net/',
  apiUrl: 'api/',
};
