export const environment = {
  production: true,
  mobile: true,
  desktop: false,
  server: 'https://conference-xplatform-server.azurewebsites.net/',
  apiUrl: 'api/',
};
