import { FoodIsLoadedGuard } from './food-is-loaded.guard';

export const foodGuards: any[] = [FoodIsLoadedGuard];

export * from './food-is-loaded.guard';
