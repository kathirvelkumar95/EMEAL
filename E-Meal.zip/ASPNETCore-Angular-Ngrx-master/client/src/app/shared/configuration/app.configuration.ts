import { Injectable } from '@angular/core';

@Injectable()
export class Configuration {
  title = 'eMeal';
}
