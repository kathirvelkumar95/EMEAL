export class FoodItem {
  public id: string; // GUID
  public calories: number;
  public name: string;
  public type: string;
  public created: Date;
  public imageString: string;
}
